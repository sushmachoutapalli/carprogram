package com.spring;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("NewBeans.xml");
		Pojo p = (Pojo) context.getBean("e");
		String perform;
		Scanner sr = new Scanner(System.in);
		System.out.println("!!!please select to perform actions as insert,display,exit!!!");
		perform = sr.next();
		while (!perform.equals("exit")) {
			switch (perform) {
			case "insert":

				System.out.println("enter the value for carid=");
				p.setId(sr.nextInt());
				System.out.println("enter the value for carname=");
				p.setName(sr.next());
				System.out.println("enter the value for carYear=");
				p.setYear(sr.nextInt());
				CarDao dao = context.getBean("cdao", CarDao.class);
				dao.saveCardetails(p);
				System.out.println("Added data successfully");
				System.out.println("!!!please select to perform actions as insert,display,exitBye!!!");
				perform = sr.next();
				break;
			case "display":
				CarDao dao1 = context.getBean("cdao", CarDao.class);
				List<Pojo> list = dao1.getAllEmployeesRowMapper();
				list.forEach(info -> System.out.println(info));
				System.out.println("!!!please select to perform actions as insert,display,exit!!!");
				perform = sr.next();
				break;
			default:
				System.out.println("please enter insert,display,exit");
				perform = sr.next();
			}
		}
		System.out.println("good bye!!!!!!!!!");
	}

}
