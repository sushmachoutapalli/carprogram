package com.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class CarDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void saveCardetails(Pojo car) {
		String insertcarInfo = "insert into Car values(" + car.getId() + ",'" + car.getName() + "'," + car.getYear()
				+ ")";
		jdbcTemplate.update(insertcarInfo);

	}

	public List<Pojo> getAllEmployeesRowMapper() {
		return jdbcTemplate.query("select * from car", new RowMapper<Pojo>() {
			public Pojo mapRow(ResultSet rs, int rownumber) throws SQLException {
				Pojo e = new Pojo();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setYear(rs.getInt(3));
				return e;
			}
		});

	}
}
